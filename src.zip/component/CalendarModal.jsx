import React, {useState} from 'react';
import './CalendarModal.css';
import {useNavigate} from 'react-router-dom';

const CalendarModal = ({show, onClose, cityName}) => {
    const today = new Date();
    const [currentMonth, setCurrentMonth] = useState(today.getMonth());
    const [currentYear, setCurrentYear] = useState(today.getFullYear());
    const [selectedDate, setSelectedDate] = useState(null);
    const [selectedRange, setSelectedRange] = useState([]); // 연속된 날짜 선택
    const navigate = useNavigate();


    // 요일 배열
    const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    // 공휴일 목록
    const holidays = [
        {month: 1, day: 1, name: "New Year's Day"},
        {month: 3, day: 1, name: 'Independence Movement Day'},
        {month: 5, day: 5, name: "Children's Day"},
        {month: 6, day: 6, name: 'Memorial Day'},
        {month: 8, day: 15, name: 'Liberation Day'},
        {month: 10, day: 3, name: 'National Foundation Day'},
        {month: 10, day: 9, name: 'Hangul Day'},
        {month: 12, day: 25, name: 'Christmas Day'},
    ];

    // 현재 월의 첫 번째 날이 무슨 요일인지 확인
    const getFirstDayOfMonth = (year, month) => new Date(year, month, 1).getDay();

    // 현재 월의 총 일수 확인
    const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();

    // 달력의 날짜를 생성하는 함수 (이전 달과 다음 달 날짜 포함)
    const generateCalendarDays = () => {
        const firstDayOfMonth = getFirstDayOfMonth(currentYear, currentMonth);
        const daysInMonth = getDaysInMonth(currentYear, currentMonth);
        const prevMonthDays = getDaysInMonth(currentYear, currentMonth - 1);

        const calendarDays = [];


        // 이전 달의 날짜 채우기
        for (let i = firstDayOfMonth - 1; i >= 0; i--) {
            calendarDays.push({day: prevMonthDays - i, type: 'prev'});
        }

        // 현재 달의 날짜 채우기
        for (let day = 1; day <= daysInMonth; day++) {
            calendarDays.push({day, type: 'current'});
        }

        // 다음 달의 날짜 채우기
        const remainingSpaces = 7 - (calendarDays.length % 7);
        if (remainingSpaces < 7) {
            for (let i = 1; i <= remainingSpaces; i++) {
                calendarDays.push({day: i, type: 'next'});
            }
        }

        return calendarDays;
    };

    const calendarDays = generateCalendarDays();

    // 공휴일인지 확인하는 함수
    const isHoliday = (day) => holidays.some((holiday) => holiday.month === currentMonth + 1 && holiday.day === day);

    // 날짜 클릭 핸들러
    const onDateClick = (day, type) => {
        if (type !== 'current') return;

        if (selectedRange.length === 0) {
            setSelectedRange([day]);
        } else if (selectedRange.length === 1) {
            const newRange = [selectedRange[0], day].sort((a, b) => a - b);
            setSelectedRange(newRange);
        } else {
            setSelectedRange([day]);
        }
    };

    const isInRange = (day) => {
        if (selectedRange.length < 2) return false;
        return day >= selectedRange[0] && day <= selectedRange[1];
    };

    /* 날짜 범위를 포맷하는 함수 */
    const formatSelectedRange = () => {
        if (selectedRange.length === 1) {
            return `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(selectedRange[0]).padStart(2, '0')}`;
        }
        if (selectedRange.length === 2) {
            return `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(selectedRange[0]).padStart(2, '0')} 
            ~ ${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(selectedRange[1]).padStart(2, '0')}`;
        }
        return '';
    };

    const handleNext = () => {
        if (selectedRange.length === 2) {
            const startDate = new Date(currentYear, currentMonth, selectedRange[0]).toISOString().split('T')[0];
            const endDate = new Date(currentYear, currentMonth, selectedRange[1]).toISOString().split('T')[0];

            navigate('/plan-trip', {state: {cityName, startDate, endDate}});
        }
    };

    // 이전 월로 이동
    const handlePrevMonth = () => {
        setCurrentMonth((prev) => (prev === 0 ? 11 : prev - 1));
        setCurrentYear((prev) => (currentMonth === 0 ? prev - 1 : prev));
    };

    // 다음 월로 이동
    const handleNextMonth = () => {
        setCurrentMonth((prev) => (prev === 11 ? 0 : prev + 1));
        setCurrentYear((prev) => (currentMonth === 11 ? prev + 1 : prev));
    };

    if (!show) return null;

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <h3>{cityName} 여행 날짜를 선택하세요</h3>
                <div className="month-navigation">
                    <button onClick={handlePrevMonth}>◀</button>
                    <span className="month">{currentYear}. {String(currentMonth + 1).padStart(2, '0')}</span>
                    <button onClick={handleNextMonth}>▶</button>
                </div>
                <div className="calendar">
                    {/* 요일 헤더 */}
                    {weekdays.map((weekday, index) => (
                        <div key={index} className="weekday">{weekday}</div>
                    ))}

                    {/*날짜 셀*/}
                    {calendarDays.map((item, index) => {
                        const {day, type} = item;
                        const isToday =
                            type === 'current' &&
                            day === today.getDate() &&
                            currentMonth === today.getMonth() &&
                            currentYear === today.getFullYear();
                        const isSunday = index % 7 === 0;
                        const isSaturday = index % 7 === 6;
                        const holiday = type === 'current' && isHoliday(day);
                        const inRange = type === 'current' && isInRange(day);
                        const isStart = selectedRange[0] === day;
                        const isEnd = selectedRange[1] === day;

                        return (
                            <div
                                key={index}
                                className={`day 
                ${type === 'prev' ? 'prev-month' : ''}
                ${type === 'next' ? 'next-month' : ''}
                ${isToday ? 'today' : ''}
                ${isSunday ? 'sunday' : ''}
                ${isSaturday ? 'saturday' : ''}
                ${holiday ? 'holiday' : ''}
                ${inRange ? 'in-range' : ''}
                ${isStart ? 'range-start' : ''}
                ${isEnd ? 'range-end' : ''}
            `}
                                onClick={() => onDateClick(day, type)}
                            >
                                {day}
                            </div>
                        );
                    })}
                </div>
                <div className="selected-dates">
                    {selectedRange.length > 0 && <p>여행 갈 날짜: {formatSelectedRange()}</p>}
                </div>
                <button onClick={handleNext} className="next-button">
                    다음
                </button>
            </div>
        </div>
    );
};

export default CalendarModal;
