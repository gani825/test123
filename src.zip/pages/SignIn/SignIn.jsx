import React from 'react';

function SignIn() {
    return <h1>로그인 페이지</h1>;
}

export default SignIn;
