import React from 'react';

function Attractions() {
    return <h1>관광지 및 여행 시설 페이지</h1>;
}

export default Attractions;
