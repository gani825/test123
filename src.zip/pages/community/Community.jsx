import React from 'react';

function Community() {
    return <h1>커뮤니티 페이지</h1>;
}

export default Community;
